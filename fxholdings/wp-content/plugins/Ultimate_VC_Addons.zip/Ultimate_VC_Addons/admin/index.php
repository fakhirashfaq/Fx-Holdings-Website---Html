<?php
/*Silence is Golden*/